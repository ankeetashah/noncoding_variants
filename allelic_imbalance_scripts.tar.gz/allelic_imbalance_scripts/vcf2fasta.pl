#!/usr/bin/perl -w

use strict;
use Carp;

use File::Basename;
use Getopt::Long;
use Bio::SeqIO;

use Vcf;
use Sequence;
use Common;
use MyConfig;


my $prog = basename ($0);
my $progDir = dirname ($0);

my $verbose = 0;
my $ext = 10;
my $org = "mm10";

my $cache = getDefaultCache ($prog);


GetOptions ("ext:i"=>\$ext,
		"org:s"=>\$org,
		"v"=>\$verbose);


if (@ARGV != 3)
{
	print "get flanking sequences around SNP\n";
	print "Usage: $prog [options] <snp.vcf> <snp.ref.fa> <snp.alt.fa>\n";
	print " -org   [string]: organism <[mm10]|hg19|rn5\n";
	print " -ext   [int]   : nucleotides to be extended on both sides ($ext)\n";
	print " -v             : verbose\n";
	exit (1);
}


my ($inVcfFile, $outRefFastaFile, $outAltFastaFile) = @ARGV;

system ("mkdir $cache");


print "loading vcf file ...\n" if $verbose;
my $fin;

open ($fin, "<$inVcfFile") || Carp::croak "cannot open file $inVcfFile to read\n";

my $tmpBedFile = "$cache/snv.bed";
my $tmpAlleleFile = "$cache/snv.allele.txt";

my ($foutBed, $foutAllele);
open ($foutBed, ">$tmpBedFile") || Carp::croak "cannot open file $tmpBedFile to write\n";
open ($foutAllele, ">$tmpAlleleFile") || Carp::croak "cannot open file $tmpAlleleFile to write\n";

my $iter = 0;
while (my $line =<$fin>)
{
	chomp $line;
	next if $line =~/^\#/;
	next if $line =~/^\s*$/;

	print "$iter ...\n" if $verbose && $iter % 100000 == 0;
	$iter++;

	my $snv = lineToVcf ($line);
	
	my $chrom = $snv->{'chrom'};
    my $chromStart = $snv->{'position'} - $ext; #zero-based coordinate
    my $chromEnd = $snv->{'position'} + $ext;
    my $name = $snv->{'id'};
	my $score = $snv->{'qual'} eq '.' ? 0 : $snv->{'qual'};
	my $strand = exists $snv->{'info'}{'strand'} ? $snv->{'info'}{'strand'} : '+';

	Carp::croak "wrong strand for snv:\n", Dumper ($snv), "\n" unless $strand eq '+' || $strand eq '-';

	my ($refBase, $altBase) = ($snv->{'refBase'}, $snv->{'altBase'});
	
	#we allow only SNV for now
	Carp::croak "not SNV:\n", Dumper ($snv), "\n" unless $refBase=~/^[ACGT]$/i && $altBase=~/^[ACGT]$/i;

    if ($strand eq '-')
    {
		#get nucleotide on the sense strand
        $refBase = complement ($refBase);
        $altBase = complement ($altBase);
    }
	
	print $foutBed join("\t", $chrom, $chromStart, $chromEnd + 1, $name, $score, $strand), "\n";
	print $foutAllele join("\t", $name, $refBase, $altBase), "\n";

}
close ($fin);
close ($foutBed);
close ($foutAllele);


print "extract sequences for the reference allele...\n" if $verbose;

my $verboseFlag = $verbose ? "-v" : "";

my $cmd = "perl $progDir/bed2fasta.pl $verboseFlag -org $org -s $tmpBedFile $outRefFastaFile";

my $ret = system ($cmd);
Carp::croak "CMD=$cmd failed: $?\n" if $ret != 0;

  
print "write sequences for the alternative allele...\n" if $verbose;

my $seqIO = Bio::SeqIO->new (-file=>$outRefFastaFile, -format=> 'Fasta');

open ($fin, "<$tmpAlleleFile") || Carp::croak "cannot open file $tmpAlleleFile to read\n";

my $fout;
open ($fout, ">$outAltFastaFile") || Carp::croak "cannot open file $outAltFastaFile to write\n";


$iter = 0;
while (my $seq = $seqIO->next_seq ())
{
	my $seqId = $seq-> id();
	my $seqDesc = $seq-> desc();
	my $seqStr = $seq->seq();
	
	my $line = <$fin>;
	chomp $line;
	my ($name, $refBase, $altBase) = split ("\t", $line);
	
	Carp::croak "inconsistency in bed and allele file\n" if $seqId ne $name;

	print "$iter ...\n" if $iter % 100000 == 0 && $verbose;
	$iter++;	

	if (length($seqStr) != $ext * 2 + 1)
	{
		print "unexpected sequence length for $seqId, skipped\n";
		next;
	}

	$refBase = substr($seqStr, $ext, 1);
	if ($refBase=~/[acgt]/)
	{
		$altBase = lc ($altBase);	
	}
	substr($seqStr, $ext, 1) = $altBase;

	print $fout ">$seqId $seqDesc\n$seqStr\n";	
}
close ($fout);


system ("rm -rf $cache");
